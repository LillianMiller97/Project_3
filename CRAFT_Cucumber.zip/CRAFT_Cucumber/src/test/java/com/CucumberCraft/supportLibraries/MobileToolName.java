package com.CucumberCraft.supportLibraries;

public enum MobileToolName {

	/**
	 * Use Appium for execution
	 */
	APPIUM,

}
